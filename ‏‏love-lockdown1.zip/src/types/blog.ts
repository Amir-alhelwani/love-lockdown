export type Blog = {
  id: number;
  title: string;
  image: string;
  description: string;
};
