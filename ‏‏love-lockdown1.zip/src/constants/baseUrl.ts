const baseUrl = "https://localhost:7096";

export default baseUrl;
