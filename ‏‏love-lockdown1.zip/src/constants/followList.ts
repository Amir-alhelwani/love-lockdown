import img1 from "@/assets/images/follow/01.jpg";
import img2 from "@/assets/images/follow/02.jpg";
import img3 from "@/assets/images/follow/03.jpg";
import img4 from "@/assets/images/follow/04.jpg";
import img5 from "@/assets/images/follow/05.jpg";
import img6 from "@/assets/images/follow/06.jpg";

const followList = [
  {
    id: 1,
    title: "@wix: #wix, #website, #freewebsite, #websitetemplate, #wix.com",
    image: img1,
  },
  {
    id: 2,
    title: "@wix: #wix, #website, #freewebsite, #websitetemplate, #wix.com",
    image: img2,
  },
  {
    id: 3,
    title: "@wix: #wix, #website, #freewebsite, #websitetemplate, #wix.com",
    image: img3,
  },
  {
    id: 4,
    title: "@wix: #wix, #website, #freewebsite, #websitetemplate, #wix.com",
    image: img4,
  },
  {
    id: 5,
    title: "@wix: #wix, #website, #freewebsite, #websitetemplate, #wix.com",
    image: img5,
  },
  {
    id: 6,
    title: "@wix: #wix, #website, #freewebsite, #websitetemplate, #wix.com",
    image: img6,
  },
];

export default followList;
