import backgroundImage from "@/assets/images/final 111-10.webp";
import image from "@/assets/images/final 111-03.webp";

const escapeRoomsIntro = {
  title: "our escape rooms",
  subtitle: "making dating fun",
  text: "our escape rooms are designed to provide you with an immersive experience that will take your dating life to the next level. We offer a variety of themes and difficulty levels to choose from, so you can customize your experience according to your preferences and skill level.",
  image,
  backgroundImage,
};

export default escapeRoomsIntro;
