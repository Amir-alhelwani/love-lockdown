const heroContent = {
  title: "love lockdown",
  subtitle: "an innovative dating concept",
  text: "Love Lockdown is an innovative dating concept that transforms the typical dating experience into an exciting escape room adventure. Participants can purchase tickets for this unique event online through a website, including regular, smart and Premium, depending on age, availability, and the escape room theme.",
  button: "book now",
};

export default heroContent;
