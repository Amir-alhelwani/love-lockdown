export const navLinks = [
  { id: 1, path: "/", label: "home" },
  { id: 2, path: "/escape-rooms", label: "escape rooms" },
  { id: 3, path: "/blog", label: "love lockdown blog" },
];
