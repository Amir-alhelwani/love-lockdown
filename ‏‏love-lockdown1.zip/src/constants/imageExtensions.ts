const imageExtensions = [
    ".apng",
    ".jfif",
    ".avif",
    ".jpg",
    ".jpeg",
    ".png",
    ".gif",
    ".pjpeg",
    ".pjp",
    ".svg",
    ".webp",
  ];
  
  export default imageExtensions;
  