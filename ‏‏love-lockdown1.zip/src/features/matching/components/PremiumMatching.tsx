
const PremiumMatching = () => {
  return <div></div>;
};

export default PremiumMatching;
